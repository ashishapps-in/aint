
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { AspectRatio, ImageSize } from "../types";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Nano Banana (Flash) for fast editing
 */
export async function editImageGemini(prompt: string, base64Image: string): Promise<string> {
  const ai = getAI();
  const [header, data] = base64Image.split(',');
  const mimeType = header.split(':')[1].split(';')[0];

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        { inlineData: { data, mimeType } },
        { text: prompt },
      ],
    },
  });

  if (response.candidates?.[0]?.content?.parts) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
  }
  throw new Error("Gemini returned no edited image.");
}

/**
 * Nano Banana Pro for High-Quality Generation
 */
export async function generateImagePro(
  prompt: string, 
  aspectRatio: AspectRatio = '1:1', 
  imageSize: ImageSize = '1K'
): Promise<string> {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: { parts: [{ text: prompt }] },
    config: {
      imageConfig: {
        aspectRatio: aspectRatio as any,
        imageSize: imageSize as any
      }
    }
  });

  if (response.candidates?.[0]?.content?.parts) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
  }
  throw new Error("Gemini Pro returned no image.");
}

/**
 * Veo Video Generation
 */
export async function generateVideoVeo(prompt: string, base64Image?: string, isPortrait = false): Promise<string> {
  const ai = getAI();
  const config: any = {
    numberOfVideos: 1,
    resolution: '720p',
    aspectRatio: isPortrait ? '9:16' : '16:9'
  };

  const payload: any = {
    model: 'veo-3.1-fast-generate-preview',
    prompt,
    config
  };

  if (base64Image) {
    const [header, data] = base64Image.split(',');
    payload.image = {
      imageBytes: data,
      mimeType: header.split(':')[1].split(';')[0],
    };
  }

  let operation = await ai.models.generateVideos(payload);
  
  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 10000));
    operation = await ai.operations.getVideosOperation({ operation: operation });
  }

  const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!downloadLink) throw new Error("Video generation failed.");
  
  const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
  const blob = await response.blob();
  return URL.createObjectURL(blob);
}

/**
 * Chat with Search Grounding
 */
export async function chatWithGemini(message: string, history: any[] = []): Promise<{ text: string; sources: any[] }> {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: history.concat([{ role: 'user', parts: [{ text: message }] }]),
    config: {
      tools: [{ googleSearch: {} }],
    },
  });

  const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks
    ?.filter((chunk: any) => chunk.web)
    ?.map((chunk: any) => ({
      title: chunk.web.title,
      uri: chunk.web.uri
    })) || [];

  return {
    text: response.text || "No response.",
    sources
  };
}

/**
 * Image Analysis (Vision)
 */
export async function analyzeImageGemini(prompt: string, base64Image: string): Promise<string> {
  const ai = getAI();
  const [header, data] = base64Image.split(',');
  const mimeType = header.split(':')[1].split(';')[0];

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: {
      parts: [
        { inlineData: { data, mimeType } },
        { text: prompt },
      ],
    },
  });

  return response.text || "Could not analyze image.";
}
