
import { GoogleGenAI } from "@google/genai";
import { AIProvider } from "../types";

export interface AISettings {
  provider: AIProvider;
  apiKey?: string;
}

/**
 * Main entry point for processing AI image generation or editing requests across all providers.
 */
export async function processAIRequest(
  type: 'generate' | 'edit',
  prompt: string,
  settings: AISettings,
  base64Image?: string
): Promise<string> {
  const { provider, apiKey } = settings;

  switch (provider) {
    case 'gemini':
      return handleGemini(type, prompt, base64Image);
    case 'openai':
    case 'copilot': // Microsoft Copilot usually uses OpenAI endpoints
      return handleOpenAI(type, prompt, apiKey, base64Image);
    case 'grok':
      return handleGrok(type, prompt, apiKey, base64Image);
    case 'deepseek':
      return handleDeepSeek(type, prompt, apiKey, base64Image);
    case 'leonardo':
      return handleLeonardo(type, prompt, apiKey);
    case 'firefly':
      return handleFirefly(type, prompt, apiKey);
    case 'anthropic':
      return handleAnthropic(type, prompt, apiKey);
    default:
      throw new Error(`Unsupported AI Provider: ${provider}`);
  }
}

async function handleGemini(type: 'generate' | 'edit', prompt: string, base64Image?: string): Promise<string> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = 'gemini-2.5-flash-image';
  
  const contents: any = { parts: [] };
  if (type === 'edit' && base64Image) {
    const [header, data] = base64Image.split(',');
    const mimeType = header.split(':')[1].split(';')[0];
    contents.parts.push({ inlineData: { data, mimeType } });
  }
  contents.parts.push({ text: prompt });

  const response = await ai.models.generateContent({
    model,
    contents,
    config: { imageConfig: { aspectRatio: "1:1" } }
  });

  if (response.candidates?.[0]?.content?.parts) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
  }
  throw new Error("Gemini returned no image.");
}

async function handleOpenAI(type: 'generate' | 'edit', prompt: string, apiKey?: string, base64Image?: string): Promise<string> {
  if (!apiKey) throw new Error("OpenAI API Key required");
  const endpoint = "https://api.openai.com/v1/images/generations";
  
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: "dall-e-3",
      prompt: type === 'edit' ? `Modify the provided context based on: ${prompt}` : prompt,
      n: 1,
      size: "1024x1024",
      response_format: "b64_json"
    })
  });
  const json = await response.json();
  if (json.error) throw new Error(json.error.message);
  return `data:image/png;base64,${json.data[0].b64_json}`;
}

async function handleGrok(type: 'generate' | 'edit', prompt: string, apiKey?: string, base64Image?: string): Promise<string> {
  if (!apiKey) throw new Error("xAI (Grok) API Key required");
  // Currently Grok primarily uses OpenAI-compatible chat endpoints for multimodal. 
  // We'll treat it as a generator using prompt engineering for now.
  throw new Error("Grok direct image generation API is currently specialized for X.com. Please use OpenAI or Gemini for creative tasks.");
}

async function handleDeepSeek(type: 'generate' | 'edit', prompt: string, apiKey?: string, base64Image?: string): Promise<string> {
  if (!apiKey) throw new Error("DeepSeek API Key required");
  // DeepSeek is currently optimized for code/reasoning. 
  throw new Error("DeepSeek does not currently offer a public Image Generation API.");
}

async function handleLeonardo(type: 'generate' | 'edit', prompt: string, apiKey?: string): Promise<string> {
  if (!apiKey) throw new Error("Leonardo.ai API Key required");
  const response = await fetch("https://cloud.leonardo.ai/api/rest/v1/generations", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      prompt,
      modelId: "6bef9f1b-29cb-40c7-b9df-32b51c1f67d3", // Leonardo Diffusion XL
      width: 1024,
      height: 1024,
      num_images: 1
    })
  });
  const json = await response.json();
  if (!json.sdGenerationJob) throw new Error("Leonardo generation failed");
  
  // Leonardo is asynchronous; we'd normally poll. For this implementation we'll notify the user.
  throw new Error("Leonardo.ai uses a polling-based API which requires a persistent queue. Support is coming soon.");
}

async function handleFirefly(type: 'generate' | 'edit', prompt: string, apiKey?: string): Promise<string> {
  if (!apiKey) throw new Error("Adobe Firefly API Key required");
  throw new Error("Adobe Firefly requires OAuth 2.0 and specific Enterprise permissions.");
}

async function handleAnthropic(type: 'generate' | 'edit', prompt: string, apiKey?: string): Promise<string> {
  if (!apiKey) throw new Error("Anthropic API Key required");
  throw new Error("Claude (Anthropic) is a text-focused LLM and does not generate images directly.");
}
